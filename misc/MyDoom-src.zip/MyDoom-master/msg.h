#ifndef _SYNC_MSG_H_
#define _SYNC_MSG_H_

char *msg_generate(char *email);

#endif
